package com.acme.acmetrade.services;

import com.acme.acmetrade.domain.SymbolEnum;
import org.junit.Test;

import static org.junit.Assert.*;

public class QuoteServiceTest {

    @Test
    public void getFileNames() {

        QuoteService.getFileNames().forEach(System.out::println);

    }

    @Test
    public void getFileNames1() {
        QuoteService.getFileNames(SymbolEnum.GOOG   ).forEach(System.out::println);
    }
}