package com.acme.acmetrade.endpoints;

import com.acme.acmetrade.TradeApplication;
import com.acme.acmetrade.domain.QuoteGenIn;
import com.acme.acmetrade.domain.StockQuote;
import com.acme.acmetrade.domain.SymbolEnum;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT, classes = {TradeApplication.class})

public class StockQuoteGeneratorControllerTest {

    @Autowired
    private StockQuoteGeneratorController stockQuoteGeneratorController;

    private QuoteGenIn quoteGenIn = new QuoteGenIn();
    private List<StockQuote> stockQuotesResponse = new ArrayList<>();
    private List<StockQuote> expectedResponse = new ArrayList<>();

    double openValueActual;
    double closeValueActual;
    double highValueActual;
    double lowValueActual;

    double openValueExpected;
    double closeValueExpected;


    @Before
    public void setUp() throws Exception {

        LocalDate date = LocalDate.parse("2019-09-01");
        System.out.println(date);
        quoteGenIn.setStart_date(date);
        quoteGenIn.setNoOfDays(1);
        quoteGenIn.setFunctionId("1");

        stockQuotesResponse = stockQuoteGeneratorController.GenerateQuote(SymbolEnum.GOOG, quoteGenIn);
        openValueActual = stockQuotesResponse.get(0).getOpenValue();
        closeValueActual = stockQuotesResponse.get(0).getCloseValue();
        highValueActual = stockQuotesResponse.get(0).getHighValue();
        lowValueActual = stockQuotesResponse.get(0).getLowValue();

        expectedResponse = getTestStockQuoteArray();
        openValueExpected = expectedResponse.get(0).getOpenValue();
        closeValueExpected = expectedResponse.get(0).getCloseValue();

    }

    @Test
    public void correctOpenAndCloseValuesGeneratedCorrectly() {
        Assert.assertTrue(openValueExpected == openValueActual);
        Assert.assertTrue(closeValueExpected == closeValueActual);
    }

    @Test
    public void verifyHighValueIsValid() {
        Assert.assertTrue(highValueActual >= openValueActual);
        Assert.assertTrue(highValueActual >= closeValueActual);
        Assert.assertTrue(highValueActual >= lowValueActual);
    }

    @Test
    public void verifyLowValueIsValid() {
        Assert.assertTrue(lowValueActual <= openValueActual);
        Assert.assertTrue(lowValueActual <= closeValueActual);
        Assert.assertTrue(lowValueActual <= highValueActual);
    }

    @Test
    public void checkQuoteListForFunction1ValuesSuccessTest(){
        QuoteGenIn quoteGenIn = new QuoteGenIn();
        int noOfDays = 3;
        LocalDate startDate = LocalDate.parse("2018-01-24");
        quoteGenIn.setStart_date(startDate);
        quoteGenIn.setNoOfDays(noOfDays);
        quoteGenIn.setFunctionId("1");
        List<StockQuote> stockQuoteList= stockQuoteGeneratorController.GenerateQuote(SymbolEnum.AAPL,quoteGenIn);
        Assert.assertEquals(noOfDays,stockQuoteList.size());
        Assert.assertEquals(startDate.toString(),stockQuoteList.get(0).getTxnDate());
        LocalDate endDate = quoteGenIn.getStart_date().plusDays(noOfDays-1);
        Assert.assertEquals(endDate.toString(), stockQuoteList.get(noOfDays-1).getTxnDate());
        Assert.assertEquals(SymbolEnum.AAPL,stockQuoteList.get(0).getSymbol());
    }

    @Test
    public void checkQuoteListForInvalidFunctionValuesSuccessTest(){

        QuoteGenIn quoteGenIn = new QuoteGenIn();
        int noOfDays = 3;
        LocalDate startDate = LocalDate.parse("2018-01-24");
        quoteGenIn.setStart_date(startDate);
        quoteGenIn.setNoOfDays(noOfDays);
        quoteGenIn.setFunctionId("4");
        List<StockQuote> stockQuoteList= stockQuoteGeneratorController.GenerateQuote(SymbolEnum.GOOG,quoteGenIn);
        Assert.assertEquals (160.0, stockQuoteList.get(0).getOpenValue(),0);
    }

    private List<StockQuote> getTestStockQuoteArray() {
        List<StockQuote> expectedResponse = new ArrayList<>();
        StockQuote stockQuote1 = new StockQuote();
        stockQuote1.setSymbol(SymbolEnum.GOOG);
        LocalDate date1 = LocalDate.parse("2019-09-01");
        stockQuote1.setTxnDate(date1.toString());
        stockQuote1.setOpenValue(160.21);
        stockQuote1.setCloseValue(161.09);
        expectedResponse.add(stockQuote1);
        return expectedResponse;
    }


}