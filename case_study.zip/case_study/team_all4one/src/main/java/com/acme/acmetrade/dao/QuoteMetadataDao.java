package com.acme.acmetrade.dao;

import com.acme.acmetrade.domain.FileMetaDataOut;
import com.acme.acmetrade.domain.QuoteGenIn;
import com.acme.acmetrade.domain.StockQuote;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class QuoteMetadataDao {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    public boolean insertQuoteMetadata(String fileName, QuoteGenIn quoteGenIn)  {
        String sqlStatement;
        sqlStatement = "INSERT INTO QUOTE_METADATA " +
                "VALUES ('" + fileName + "','" + quoteGenIn.getSymbol() + "', '" +  quoteGenIn.getStart_date() + "', " + quoteGenIn.getNoOfDays() + ", '" + quoteGenIn.getFunctionId() + "')";
        DatabaseConnection databaseConnection = new DatabaseConnection();
        Connection conn = null;
        try {
            conn = databaseConnection.getConnection();
            Statement statement = conn.createStatement();
            statement.executeUpdate(sqlStatement);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return true;
    }

    public List<FileMetaDataOut> getQuoteMetadata() {
        String sqlStatement;
        sqlStatement = "SELECT * FROM QUOTE_METADATA";
        DatabaseConnection databaseConnection = new DatabaseConnection();
        Connection conn = null;
        List<FileMetaDataOut> fileMetaDataOuts = null;
        try {
            conn = databaseConnection.getConnection();
            Statement statement = conn.createStatement();
            ResultSet resultSet = statement.executeQuery(sqlStatement);
            FileMetaDataOut fileMetaDataOut;
            QuoteGenIn quoteGenIn;
            fileMetaDataOuts = new ArrayList<>();
            while (resultSet.next()) {
                fileMetaDataOut = new FileMetaDataOut();
                fileMetaDataOut.setFileName(resultSet.getString("ID"));
                quoteGenIn = new QuoteGenIn();
                quoteGenIn.setFunctionId(resultSet.getString("FUNCTION_ID"));
                quoteGenIn.setNoOfDays(resultSet.getInt("NO_OF_DAYS"));
                quoteGenIn.setStart_date(resultSet.getDate("START_DATE").toLocalDate());
                fileMetaDataOut.setQuoteOut(quoteGenIn);

                fileMetaDataOuts.add(fileMetaDataOut);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return fileMetaDataOuts;
    }

}
