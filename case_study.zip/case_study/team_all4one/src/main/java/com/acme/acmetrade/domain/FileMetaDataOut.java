package com.acme.acmetrade.domain;

import com.fasterxml.jackson.annotation.JsonEnumDefaultValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class FileMetaDataOut {

    @JsonProperty
    private String fileName;

    @JsonProperty
    private QuoteGenIn quoteOut;

    public FileMetaDataOut() {
    }

    public FileMetaDataOut(String fileName, QuoteGenIn quoteOut) {
        this.fileName = fileName;
        this.quoteOut = quoteOut;
    }

    @Override
    public String toString() {
        return "FileMetaDataOut{" +
                "fileName='" + fileName + '\'' +
                ", quoteOut=" + quoteOut +
                '}';
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public QuoteGenIn getQuoteOut() {
        return quoteOut;
    }

    public void setQuoteOut(QuoteGenIn quoteOut) {
        this.quoteOut = quoteOut;
    }
}
