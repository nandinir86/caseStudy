package com.acme.acmetrade.domain;

public enum SymbolEnum {
    AAPL("AAPL"),
    GOOG("GOOG"),
    MSFT("MSFT"),
    GS("GS"),
    QCOM("QCOM"),
    GE("GE");

    private final String value;

    SymbolEnum(final String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return value;
    }
}
