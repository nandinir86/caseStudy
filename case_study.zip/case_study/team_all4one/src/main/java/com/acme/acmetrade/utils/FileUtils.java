package com.acme.acmetrade.utils;

        import com.acme.acmetrade.domain.StockQuote;
        import com.acme.acmetrade.domain.SymbolEnum;

        import java.io.File;
        import java.io.FileWriter;
        import java.io.IOException;
        import java.nio.file.Files;
        import java.nio.file.Paths;
        import java.util.List;
        import java.util.stream.Collectors;
        import java.util.stream.Stream;

public class FileUtils {

    public static void parse(Stream<StockQuote> lines, String output) throws IOException {
        final FileWriter fw = new FileWriter(output);

        lines.forEach(quo -> writeToFile(fw, quo));
        fw.close();
        lines.close();
    }

    private static void writeToFile(FileWriter fw, StockQuote quote) {
        try {
            //fw.write(String.format("%s%n", quote));
            fw.write(String.format("%s%n",quote.toStringForFile()));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public static List<String> listAllFiles(String filePath) throws IOException {
        File directory = new File(filePath);
            Stream<String> filesStream = Files.list(Paths.get(filePath)).map(path -> path.getFileName().toString());
            List<String> filesList = filesStream.collect(Collectors.toList());
        return filesList;

    }
    public static List<String> listAllFiles(String filePath,SymbolEnum symbol) throws IOException {
        File directory = new File(filePath);
        Stream<String> filesStream = Files.list(Paths.get(filePath)).map(path -> path.getFileName().toString());
        List<String> filesList = filesStream.filter(o->o.contains(symbol.toString())). collect(Collectors.toList());
        return filesList;

    }

    public static List<String> listAllFiles(String filePath,String functionId) throws IOException {
        File directory = new File(filePath);
        Stream<String> filesStream = Files.list(Paths.get(filePath)).map(path -> path.getFileName().toString());
        List<String> filesList = filesStream.filter(o->o.contains("_"+functionId+".")). collect(Collectors.toList());
        return filesList;

    }

    public static List<String> listAllFiles(String filePath,SymbolEnum symbol,String functionId) throws IOException {
        File directory = new File(filePath);
        Stream<String> filesStream = Files.list(Paths.get(filePath)).map(path -> path.getFileName().toString());
        List<String> filesList = filesStream.collect(Collectors.toList());
        return filesList;

    }
}
