package com.acme.acmetrade.utils;

import java.util.Random;

public class NumberGenerationUtil {

    private static final float MIN_PRICE = 0;
    private static final float MAX_PRICE = 1000;

    public static float getNextPrice(float oldPrice)
    {
        // Instead of a fixed volatility, pick a random volatility
        // each time, between 2 and 10.
        Random r = new Random();
        float volatility = r.nextFloat() * 10 + 2;

        float rnd = r.nextFloat();

        float changePercent = 2 * volatility * rnd;

        if (changePercent > volatility) {
            changePercent -= (2 * volatility);
        }
        float changeAmount = oldPrice * changePercent/100;
        float newPrice = oldPrice + changeAmount;

        // Add a ceiling and floor.
        if (newPrice < MIN_PRICE) {
            newPrice += Math.abs(changeAmount) * 2;
        } else if (newPrice > MAX_PRICE) {
            newPrice -= Math.abs(changeAmount) * 2;
        }

        return newPrice;

    }

}
