package com.acme.acmetrade.domain;


public class StockQuote {

    private SymbolEnum symbol;
    private String txnDate;
    private double openValue;
    private double highValue;
    private double lowValue;
    private double closeValue;
    private long volume;

    public SymbolEnum getSymbol() {
        return symbol;
    }

    @Override
    public String toString() {
        return "StockQuote{" +
                "symbol=" + symbol +
                ", txnDate='" + txnDate + '\'' +
                ", openValue=" + openValue +
                ", highValue=" + highValue +
                ", lowValue=" + lowValue +
                ", closeValue=" + closeValue +
                ", volume=" + volume +
                '}';
    }

    public String toStringForFile() {
        return  symbol + "|" + txnDate + "|" + openValue + "|" + highValue + "|" + lowValue +
                "|" + closeValue + "|" + volume;
    }

    public void setSymbol(SymbolEnum symbol) {
        this.symbol = symbol;
    }

    public String getTxnDate() {
        return txnDate;
    }

    public void setTxnDate(String txnDate) {
        this.txnDate = txnDate;
    }

    public double getOpenValue() {
        return openValue;
    }

    public void setOpenValue(Double openValue) {
        this.openValue = Math.floor(openValue*100)/100;
    }

    public double getHighValue() {
        return highValue;
    }

    public void setHighValue(Double highValue) {
        this.highValue = Math.floor(highValue*100)/100;
    }

    public double getLowValue() {
        return lowValue;
    }

    public void setLowValue(Double lowValue) {
        this.lowValue = Math.floor(lowValue*100)/100;
    }

    public double getCloseValue() {
        return closeValue;
    }

    public void setCloseValue(Double closeValue) {
        this.closeValue = Math.floor(closeValue*100)/100;
    }

    public long getVolume() {
        return volume;
    }

    public void setVolume(long volume) {
        this.volume = volume;
    }
}
