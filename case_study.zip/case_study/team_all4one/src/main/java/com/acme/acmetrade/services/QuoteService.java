package com.acme.acmetrade.services;

import com.acme.acmetrade.dao.QuoteMetadataDao;
import com.acme.acmetrade.domain.FileMetaDataOut;
import com.acme.acmetrade.domain.QuoteGenIn;
import com.acme.acmetrade.domain.StockQuote;
import com.acme.acmetrade.domain.SymbolEnum;
import com.acme.acmetrade.utils.FileUtils;
import com.acme.acmetrade.utils.RandQuoteGenerator;
import com.fasterxml.jackson.annotation.JacksonInject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;


public class QuoteService {

    public static List<StockQuote> generateQuote(QuoteGenIn quoteGenIn, SymbolEnum symbol, int initConstant) throws IOException {
        double x = initConstant;
        List<StockQuote> stockQuotes = RandQuoteGenerator.quoteGenerator(quoteGenIn, x);

        for (StockQuote stockQuote : stockQuotes) {

            //add symbol
            stockQuote.setSymbol(symbol);
            quoteGenIn.setSymbol(symbol);

            //add date
            LocalDate ldt = quoteGenIn.getStart_date().plusDays(stockQuotes.indexOf(stockQuote));
            stockQuote.setTxnDate(ldt.format(DateTimeFormatter.ofPattern("y-MM-dd")));

        }

        //write open a file and write to it
        String dateT = LocalDateTime.now().toString().replace(":", "");
        String fileName = "C:/Users/student/Files/StockQuote_" + symbol.toString() + "_" + dateT + "_" + quoteGenIn.getFunctionId() + ".csv";
        FileUtils.parse(stockQuotes.stream(), fileName);
        QuoteMetadataDao quoteMetadataDao = new QuoteMetadataDao();
       // boolean boolDone = quoteMetadataDao.insertQuoteMetadata("abc.csv",quoteGenIn);
        return stockQuotes;
    }


    public static List<FileMetaDataOut> getFiles(SymbolEnum symbolEnum, String functionId)  {
        QuoteMetadataDao quoteMetadataDao = new QuoteMetadataDao();

            List<FileMetaDataOut> fileMetaDataOuts = quoteMetadataDao.getQuoteMetadata();

            if (!StringUtils.isEmpty(functionId)) {

                fileMetaDataOuts = evaluate(fileMetaDataOuts, o -> o.getQuoteOut().getFunctionId() == functionId);
        }
        if (!StringUtils.isEmpty(symbolEnum)) {

            fileMetaDataOuts = evaluate(fileMetaDataOuts, o -> o.getQuoteOut().getSymbol() == symbolEnum);
        }

        return fileMetaDataOuts;

    }



    static List<FileMetaDataOut> evaluate(List<FileMetaDataOut> fileMetaDataOuts,
                                          Predicate<FileMetaDataOut> predicate) {
        fileMetaDataOuts.stream().filter(predicate).collect(Collectors.toList());


        return fileMetaDataOuts;
    }

    public static List<String> getFileNames()  {

        List<String> fileMetaDataOuts = null;
        try {
            fileMetaDataOuts = FileUtils.listAllFiles("C:/Users/student/Files/");
        } catch (IOException e) {
            e.printStackTrace();
        }

        return fileMetaDataOuts;

    }
    public static List<String> getFileNames(SymbolEnum symbol)  {

        List<String> fileMetaDataOuts = null;
        try {
            fileMetaDataOuts = FileUtils.listAllFiles("C:/Users/student/Files/",symbol);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return fileMetaDataOuts;

    }
    public static List<String> getFileNames(String functionId)  {

        List<String> fileMetaDataOuts = null;
        try {
            fileMetaDataOuts = FileUtils.listAllFiles("C:/Users/student/Files/",functionId);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return fileMetaDataOuts;

    }
    public static List<String> getFileNames(SymbolEnum symbol,String functionId)  {

        List<String> fileMetaDataOuts = null;
        try {
            fileMetaDataOuts = FileUtils.listAllFiles("C:/Users/student/Files/",symbol,functionId);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return fileMetaDataOuts;

    }
}