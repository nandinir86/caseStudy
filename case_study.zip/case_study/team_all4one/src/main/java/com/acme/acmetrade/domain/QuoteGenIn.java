package com.acme.acmetrade.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.tomcat.jni.Local;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import java.time.LocalDate;
import java.util.Date;


public class QuoteGenIn {

    @JsonProperty
    private int noOfDays;

    @JsonProperty
    private LocalDate start_date;

    @JsonProperty
    @Min(1)
    @Max(3)
    private String functionId;

    @JsonProperty
    SymbolEnum symbol;

    public SymbolEnum getSymbol() {
        return symbol;
    }

    public void setSymbol(SymbolEnum symbol) {
        this.symbol = symbol;
    }

    public QuoteGenIn() {
    }

    public QuoteGenIn(int noOfDays, LocalDate start_date, String functionId) {
        this.noOfDays = noOfDays;
        this.start_date = start_date;
        this.functionId = functionId;
    }


    public int getNoOfDays() {
        return noOfDays;
    }

    public void setNoOfDays(int noOfDays) {
        this.noOfDays = noOfDays;
    }

    public LocalDate getStart_date() {
        return start_date;
    }

    public void setStart_date(LocalDate start_date) {
        this.start_date = start_date;
    }

    public String getFunctionId() {
        return functionId;
    }

    public void setFunctionId(String functionId) {
        this.functionId = functionId;
    }
}
