package com.acme.acmetrade.endpoints;

import com.acme.acmetrade.domain.FileMetaDataOut;
import com.acme.acmetrade.domain.QuoteGenIn;
import com.acme.acmetrade.domain.StockQuote;
import com.acme.acmetrade.domain.SymbolEnum;
import com.acme.acmetrade.services.QuoteService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.io.IOException;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@RestController
public class StockQuoteGeneratorController {
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    @Value("${INTIAL_CONSTANT_X}")
    private int initConstant;

    @PostMapping(value = "/generate/{symbol}")
    public List<StockQuote> GenerateQuote(@PathVariable("symbol") SymbolEnum symbol,
                                          @RequestBody @Valid QuoteGenIn quoteGenIn) {
        log.info("no of days: " + quoteGenIn.getNoOfDays());
        log.info("function id : " + quoteGenIn.getFunctionId());
        log.info("Date : " + quoteGenIn.getStart_date());
        log.info("symbol:" + symbol);
        log.info("In generate service x: " + initConstant);
        //float newNum= numberGenerationUtil.getNextPrice(160);

        List<StockQuote> quotes = null;
        try {
            quotes = QuoteService.generateQuote(quoteGenIn, symbol, initConstant);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return quotes;
    }

//    @GetMapping(value = "/files")
//    public List<FileMetaDataOut> getFiles1(@RequestParam(name = "symbol", required = false) SymbolEnum symbol,
//                                          @RequestParam(name = "functionId", required = false) String functionId) {
//
//        List<FileMetaDataOut> fileMetaDataOuts = null;
//        if (!StringUtils.isEmpty(symbol)) log.info("symbol : " + symbol);
//        if (!StringUtils.isEmpty(functionId)) log.info("functionId : " + functionId);
//
//        // uncomment after implementation
//        //fileMetaDataOuts = QuoteService.getFiles(symbol,functionId);
//
////        if (!StringUtils.isEmpty(functionId)) {
////
////            List<FileMetaDataOut> outObj = evaluate(fileMetaDataOuts, o -> o.getQuoteOut().getFunctionId() == functionId);
////        }
////        if (!StringUtils.isEmpty(symbol)) {
////
////            List<FileMetaDataOut> outObj = evaluate(fileMetaDataOuts, o -> o.getQuoteOut().getSymbol() == symbol);
////        }
//
//        return fileMetaDataOuts;
//
//    }

    static List<FileMetaDataOut> evaluate(List<FileMetaDataOut> fileMetaDataOuts,
                                          Predicate<FileMetaDataOut> predicate) {
        fileMetaDataOuts.stream().filter(predicate).collect(Collectors.toList());


        return fileMetaDataOuts;
    }

    @GetMapping(value = "/files")
    public List<String> getFiles(@RequestParam(name = "symbol", required = false) SymbolEnum symbol,
                                           @RequestParam(name = "functionId", required = false) String functionId) {

        List<String> fileList = null;
        if (!StringUtils.isEmpty(symbol) && !StringUtils.isEmpty(functionId)){
            fileList = QuoteService.getFileNames(symbol,functionId);

        }
        else if (!StringUtils.isEmpty(symbol)) {
            fileList = QuoteService.getFileNames(symbol);
            log.info("symbol : " + symbol);
        }
        else if (!StringUtils.isEmpty(functionId)) {
            fileList = QuoteService.getFileNames(functionId);
            log.info("functionId : " + functionId);
        }
        else
        {
            fileList = QuoteService.getFileNames();
        }

        // uncomment after implementation
//        fileList = QuoteService.getFileNames(symbol,functionId);



        return fileList;
    }
}
