H2 console is available at http://localhost:8080/h2-console
H2 in-memory DB instance url: jdbc:h2:mem:testdb
user/pass: sa/[blank]

Unit testing with spring: https://docs.spring.io/spring/docs/current/spring-framework-reference/html/integration-testing.html